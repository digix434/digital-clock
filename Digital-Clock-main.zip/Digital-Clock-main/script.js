let digital_watch = document.getElementsByClassName('clock');
let stopWatch = document.getElementsByClassName('stopwatch');
let digital_clock = document.getElementById('digitalwatch');
let stop_watch = document.getElementById('stopwatch');



if (digital_watch == active)
{
stop_watch.style.display = 'hide';

digital_clock.style.display = 'block'
}
else{
    digital_clock.style.display = 'hide'
    stop_watch.style.display = 'block';
}

// digital clock logic 







//stop watch 